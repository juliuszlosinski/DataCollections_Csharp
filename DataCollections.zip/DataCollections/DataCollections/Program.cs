﻿using System;
using System.Collections.Generic;
using DataCollections.DynamicArrays;
using DataCollections.LinkedLists;
using DataCollections.Stacks;
using DataCollections.Graphs;
using DataCollections.Trees;

namespace DataCollections
{
    namespace DynamicArrays
    {
        abstract class DynamicArray<T> where T : IComparable
        {
            #region FIELDS
            protected T[] values;
            protected int count;
            #endregion

            #region CONSTRUCTORS
            public DynamicArray(int capacity)
            {
                values = new T[capacity];
                count = 0;
            }
            #endregion

            #region PROPORTIES
            public int Count { get => count; }
            #endregion

            #region METHODS
            public abstract void Add(T value);
            public abstract void Remove(T value);
            public abstract void Clear();
            public abstract override string ToString();
            #endregion
        }

        class UnOrderedDynamicArray<T> : DynamicArray<T> where T : IComparable
        {
            #region CONSTRUCTORS
            public UnOrderedDynamicArray() : this(5) { }
            public UnOrderedDynamicArray(int capacity) : base(capacity) { }
            #endregion

            #region BEHAVIOUR
            public override void Add(T value)
            {
                if (value != null)
                {
                    if (count > values.Length)
                    {
                        Extend();
                    }

                    values[count] = value;
                    count++;
                }
            }

            void Extend()
            {
                T[] newValues = new T[count * 2];
                int i = 0;
                while (i < count)
                {
                    newValues[i] = values[i];
                    i++;
                }
                values = newValues;
            }

            public override void Clear()
            {
                count = 0;
            }

            public override void Remove(T value)
            {
                int index = Find(value);
                if (index != -1)
                {
                    ShifDown(index);
                    count--;
                }
            }

            void ShifDown(int index)
            {
                int i = index + 1;
                while (i < count)
                {
                    values[i - 1] = values[i];
                    i++;
                }
            }

            int Find(T value)
            {
                for (int x = 0, y = count - 1; x < count; x++, y--)
                {
                    if (values[x].Equals(value))
                    {
                        return x;
                    }
                    else if (values[y].Equals(value))
                    {
                        return y;
                    }
                }
                return -1;
            }

            public override string ToString()
            {
                string res = "";
                int i = 0;
                while (i < count)
                {
                    res += values[i] + " ";
                    i++;
                }
                return res;
            }
            #endregion
        }

        class OrderedDynamicArray<T> : DynamicArray<T> where T : IComparable
        {
            #region CONSTRUCTORS
            public OrderedDynamicArray() : this(5) { }
            public OrderedDynamicArray(int capacity) : base(capacity) { }
            #endregion

            #region BEHAVIOUR
            public override void Add(T value)
            {
                if (value != null)
                {
                    if (count > values.Length)
                    {
                        Extend();
                    }

                    int addLocation = 0;

                    while (addLocation < count && values[addLocation].CompareTo(value) < 0)
                    {
                        addLocation++;
                    }


                    ShiftUp(addLocation);

                    values[addLocation] = value;
                    count++;
                }
            }

            void ShiftUp(int index)
            {
                int i = count;
                while (i != index)
                {
                    values[i] = values[i - 1];
                    i--;
                }
            }

            void Extend()
            {
                T[] newValues = new T[count * 2];
                int i = 0;
                while (i < count)
                {
                    newValues[i] = values[i];
                    i++;
                }
                values = newValues;
            }

            public override void Clear()
            {
                count = 0;
            }

            public override void Remove(T value)
            {
                int index = Find(0, count, value);
                if (index != -1)
                {
                    ShiftDown(index);
                    count--;
                }
            }

            void ShiftDown(int index)
            {
                int i = index + 1;
                while (i < count)
                {
                    values[i - 1] = values[i];
                    i++;
                }
            }

            int Find(int leftBound, int rightBound, T value)
            {
                if (leftBound > rightBound)
                {
                    return -1;
                }
                else
                {
                    int middleLocation = (leftBound + rightBound) / 2;
                    T middleValue = values[middleLocation];
                    if (middleValue.CompareTo(value) == 0)
                    {
                        return middleLocation;
                    }
                    else
                    {
                        if (middleValue.CompareTo(value) > 0)
                        {
                            rightBound = middleLocation - 1;
                        }
                        else
                        {
                            leftBound = middleLocation += 1;
                        }
                        return Find(leftBound, rightBound, value);
                    }
                }
            }

            public override string ToString()
            {
                string res = "";
                int i = 0;
                while (i < count)
                {
                    res += values[i] + " ";
                    i++;
                }
                return res;
            }
            #endregion
        }
    }

    namespace LinkedLists
    {
        class LinkedListNode<T> : IComparable where T : IComparable
        {
            #region FIELDS
            T value;
            LinkedListNode<T> next;
            LinkedListNode<T> previous;
            #endregion

            #region CONSTRUCTORS
            public LinkedListNode(T value, LinkedListNode<T> next, LinkedListNode<T> previous)
            {
                this.value = value;
                this.next = next;
                this.previous = previous;
            }
            #endregion

            #region PROPORTIES
            public T Value { get => value; }
            public LinkedListNode<T> Next { get => next; set => next = value; }
            public LinkedListNode<T> Previous { get => previous; set => previous = value; }

            public int CompareTo(object obj)
            {
                LinkedListNode<T> other = (LinkedListNode<T>)obj;
                if (other != null)
                {
                    int cmp = value.CompareTo(other.Value);
                    if (cmp > 0)
                    {
                        return 1;
                    }
                    else if (cmp < 0)
                    {
                        return -1;
                    }
                    else
                    {
                        return 0;
                    }
                }
                else
                {
                    throw new Exception("Object is not type of LinkedListNode!");
                }
            }
            #endregion

            #region METHODS
            public override string ToString()
            {
                string res = $"Value: {value}";
                return res;
            }
            #endregion
        }

        abstract class LinkedList<T> where T : IComparable
        {
            protected LinkedListNode<T> head;
            protected int count;

            public LinkedList(T value)
            {
                head = new LinkedListNode<T>(value, null, null);
                count = 0;
            }

            public LinkedListNode<T> Head { get => head; }
            public int Count { get => count; }

            public abstract void Add(T value);
            public abstract void Remove(T value);
        }

        class UnOrderedLinkedList<T> : LinkedList<T> where T : IComparable
        {
            #region CONSTRUCTORS
            public UnOrderedLinkedList(T value) : base(value) { }
            #endregion

            #region METHODS
            public override void Add(T value)
            {
                head = new LinkedListNode<T>(value, head, null);
                count++;
            }

            public override void Remove(T value)
            {
                if (head.Value.Equals(value))
                {
                    head = head.Next;
                }
                else
                {
                    LinkedListNode<T> previous = head;
                    LinkedListNode<T> next = head.Next;

                    while (next != null)
                    {
                        if (previous.Value.Equals(value))
                        {
                            break;
                        }
                        previous = next;
                        next = previous.Next;
                    }

                    previous = previous.Next;
                }
                count--;
            }

            public override string ToString()
            {
                string res = "";
                LinkedListNode<T> previous = head;
                LinkedListNode<T> next = head.Next;
                while (next != null)
                {
                    res += previous.ToString() + ", ";
                    previous = next;
                    next = previous.Next;
                }
                return res;
            }
            #endregion
        }

        class OrderedLinkedList<T> : LinkedList<T> where T : IComparable
        {
            #region CONSTRUCTORS
            public OrderedLinkedList(T value) : base(value) { }
            #endregion

            #region METHODS
            public override void Add(T value)
            {

                LinkedListNode<T> previous = head;
                LinkedListNode<T> next = head.Next;

                while (next != null)
                {
                    if (next.Value.CompareTo(value) > 0)
                    {
                        break;
                    }
                    else
                    {
                        previous = next;
                        next = previous.Next;
                    }
                }

                previous.Next = new LinkedListNode<T>(value, next, previous);
                count++;

                if (head.Next.Value.CompareTo(head.Value) < 0)
                {
                    T valueN = head.Next.Value;
                    T valueH = head.Value;
                    head.Next = new LinkedListNode<T>(valueH, head.Next.Next, head);
                    head = new LinkedListNode<T>(valueN, head.Next, null);
                }
            }

            public override void Remove(T value)
            {
                if (head.Value.Equals(value))
                {
                    head = head.Next;
                }
                else
                {
                    LinkedListNode<T> previous = head;
                    LinkedListNode<T> next = head.Next;

                    while (next != null)
                    {
                        if (next.Value.Equals(value))
                        {
                            break;
                        }
                        else
                        {
                            previous = next;
                            next = previous.Next;
                        }
                    }

                    previous.Next = next.Next;
                }
                count--;
            }

            public override string ToString()
            {
                string res = "";
                LinkedListNode<T> previous = head;
                LinkedListNode<T> next = head.Next;
                while (next != null)
                {
                    res += "[" + previous.ToString() + "] ";
                    previous = next;
                    next = previous.Next;
                }
                return res;
            }
            #endregion
        }
    }

    namespace Queues
    {
        class QueueNode<T> : IComparable where T : IComparable
        {
            #region FIELDS
            QueueNode<T> next;
            T value;
            #endregion

            #region CONSTRUCTORS
            public QueueNode(T value, QueueNode<T> next)
            {
                this.value = value;
                this.next = next;
            }
            #endregion

            #region PROPORTIES
            public T Value
            {
                get
                {
                    return value;
                }
            }
            
            public QueueNode<T> Next
            {
                get
                {
                    return next;
                }
                set
                {
                    next = value;
                }
            }
            #endregion

            #region METHODS
            public int CompareTo(object obj)
            {
                QueueNode<T> other = obj as QueueNode<T>;
                if (other != null)
                {
                    int cmp = value.CompareTo(other.Value);
                    if (cmp > 0)
                    {
                        return 1;
                    }
                    else if (cmp < 0)
                    {
                        return -1;
                    }
                    else
                    {
                        return 0;
                    }
                }
                else
                {
                    throw new Exception("Object is not type of QueueNode!");
                }
            }

            public override string ToString()
            {
                string res = $"Value: {Value}";
                return res;
            }
            #endregion
        }

        class Queue<T> where T : IComparable
        {
            #region FIELDS
            QueueNode<T> head;
            int count;
            #endregion

            #region CONSTRUCTORS
            public Queue(T value)
            {
                head = new QueueNode<T>(value, null);
                count = 0;
            }
            #endregion

            #region PRPORTIES
            public QueueNode<T> Head { get => head; }
            public int Count { get => count; }
            #endregion

            #region METHODS
            public void Enqueue(T value)
            {
                QueueNode<T> previous = head;
                QueueNode<T> next = head.Next;

                while (next != null)
                {
                    previous = next;
                    next = previous.Next;
                }

                previous.Next = new QueueNode<T>(value, next);

                count++;
            }

            public QueueNode<T> Dequeue()
            {
                QueueNode<T> top = head;
                head = head.Next;

                count--;

                return top;
            }

            public T Peek()
            {
                return head.Value;
            }

            public override string ToString()
            {
                string res = "";
                QueueNode<T> previous = head;
                QueueNode<T> next = head.Next;

                while (next != null)
                {
                    res += "[" + previous.ToString() + "] ";
                    previous = next;
                    next = previous.Next;
                }

                return res;
            }
            #endregion
        }
    }

    namespace Stacks
    {
        class StackNode<T> : IComparable where T : IComparable
        {
            #region FIELDS
            StackNode<T> next;
            T value;
            #endregion

            #region CONSTRUCTORS
            public StackNode(T value, StackNode<T> next)
            {
                this.value = value;
                this.next = next;
            }
            #endregion

            #region PROPORTIES
            public StackNode<T> Next
            {
                get
                {
                    return next;
                }
                set
                {
                    next = value;
                }
            }
            
            public T Value
            {
                get
                {
                    return value;
                }
            }
            #endregion

            #region METHODS
            public int CompareTo(object obj)
            {
                StackNode<T> other = obj as StackNode<T>;
                if (other != null)
                {
                    int cmp = value.CompareTo(other.Value);
                    if (cmp > 0)
                    {
                        return 1;
                    }
                    else if (cmp < 0)
                    {
                        return -1;
                    }
                    else
                    {
                        return 0;
                    }
                }
                else
                {
                    throw new Exception("Object is not type of stack node!");
                }
            }

            public override string ToString()
            {
                string res = $"Value: {value}";
                return res;
            }
            #endregion
        }
        class Stack<T> where T : IComparable
        {
            #region FIELDS
            StackNode<T> head;
            int count;
            #endregion

            #region CONSTRUCTORS
            public Stack()
            {
                count = 0;
            }

            public Stack(T value)
            {
                head = new StackNode<T>(value, null);
                count = 0;
            }
            #endregion

            #region PROPORTIES
            public StackNode<T> Head { get => head; }
            public int Count { get => count; }
            #endregion

            #region METHODS
            public void Push(T value)
            {
                if (head == null)
                {
                    head = new StackNode<T>(value, null);
                }
                else
                {
                    head = new StackNode<T>(value, head);
                }
                count++;
            }

            public StackNode<T> Pop()
            {
                StackNode<T> result = new StackNode<T>(head.Value, head.Next);
                head = head.Next;
                count--;
                return result;
            }

            public T Peek()
            {
                return head.Value;
            }

            public override string ToString()
            {
                string res = "";
                StackNode<T> previous = head;
                StackNode<T> next = head.Next;

                while (next != null)
                {
                    res += "[" + previous.ToString() + "] ";
                    previous = next;
                    next = previous.Next;
                }

                return res;
            }
            #endregion
        }
    }

    namespace Graphs
    {
        class GraphNode<T>
        {
            #region FIELDS
            T value;
            List<GraphNode<T>> neighbors;
            int numberofConnections;
            #endregion

            #region CONSTRUCTORS
            public GraphNode(T value)
            {
                this.value = value;
                neighbors = new List<GraphNode<T>>();
                numberofConnections = neighbors.Count;
            }
            #endregion

            #region PROPORTIES
            public T Value { get => value; }
            public IList<GraphNode<T>> Neighbors { get => neighbors.AsReadOnly(); }
            public int NumberOfConnections { get => neighbors.Count; }
            #endregion

            #region METHODS
            public void AddNeighbor(T value)
            {
                GraphNode<T> neighbor = new GraphNode<T>(value);
                if (!neighbors.Contains(neighbor))
                {
                    neighbors.Add(neighbor);
                }
            }

            public void RemoveNeighbor(T value)
            {
                GraphNode<T> toRemove = Find(value);
                if (toRemove != null)
                {
                    neighbors.Remove(toRemove);
                }
            }

            public void Clear()
            {
                neighbors.Clear();
            }

            GraphNode<T> Find(T value)
            {
                foreach (GraphNode<T> node in neighbors)
                {
                    if (node.value.Equals(value))
                    {
                        return node;
                    }
                }
                return null;
            }

            public bool Check(T value)
            {
                foreach (GraphNode<T> node in neighbors)
                {
                    if (node.value.Equals(value))
                    {
                        return true;
                    }
                }
                return false;
            }

            public override string ToString()
            {
                string res = $"Vertex: {value} <-> ";
                foreach (GraphNode<T> node in neighbors)
                {
                    res += node.Value + " ";
                }
                return res;
            }
            #endregion
        }
        class Graph<T>
        {
            #region FIELDS
            List<GraphNode<T>> graphNodes;
            #endregion

            #region CONSTRUCTORS
            public Graph()
            {
                graphNodes = new List<GraphNode<T>>();
            }
            #endregion

            #region PROPORTIES
            public IList<GraphNode<T>> GraphNodes { get => graphNodes.AsReadOnly(); }
            public int Count { get => graphNodes.Count; }
            #endregion

            #region METHODS
            public void AddGraphNode(T value)
            {
                if (!Check(value))
                {
                    graphNodes.Add(new GraphNode<T>(value));
                }
            }

            public void RemoveGraphNode(T value)
            {
                GraphNode<T> first = Find(value);
                if (first != null)
                {
                    first.Clear();
                    graphNodes.Remove(first);
                }
            }

            public void AddEdge(T first, T second)
            {
                GraphNode<T> firstNode = Find(first);
                GraphNode<T> secondNode = Find(second);

                if (firstNode != null && secondNode != null)
                {
                    if (!firstNode.Check(first) && !secondNode.Check(second))
                    {
                        firstNode.AddNeighbor(second);
                        secondNode.AddNeighbor(first);
                    }
                }
            }

            public void RemoveEdge(T first, T second)
            {
                GraphNode<T> firstNode = Find(first);
                GraphNode<T> secondNode = Find(second);

                if (firstNode != null && secondNode != null)
                {
                    if (firstNode.Check(second) && secondNode.Check(first))
                    {
                        firstNode.RemoveNeighbor(second);
                        secondNode.RemoveNeighbor(first);
                    }
                }
            }

            bool Check(T value)
            {
                foreach (GraphNode<T> node in graphNodes)
                {
                    if (node.Value.Equals(value))
                    {
                        return true;
                    }
                }
                return false;
            }

            public GraphNode<T> Find(T value)
            {
                foreach (GraphNode<T> node in graphNodes)
                {
                    if (node.Value.Equals(value))
                    {
                        return node;
                    }
                }
                return null;
            }

            public override string ToString()
            {
                string res = "";
                foreach (GraphNode<T> current in graphNodes)
                {
                    res += $"Vertex: {current.Value} <-> ";
                    foreach (GraphNode<T> neighbor in current.Neighbors)
                    {
                        res += $"{neighbor.Value} ";
                    }
                    res += "\n";
                }
                return res;
            }

            public bool IsConnection(T start, T meta)
            {
                GraphNode<T> startNode = Find(start);
                GraphNode<T> metaNode = Find(meta);

                if (startNode == metaNode)
                {
                    return true;
                }
                else if (startNode.Check(meta))
                {
                    return true;
                }
                else
                {
                    System.Collections.Generic.LinkedList<GraphNode<T>> nodes = new System.Collections.Generic.LinkedList<GraphNode<T>>();
                    nodes.AddFirst(startNode);

                    while (nodes.Count != 0)
                    {
                        GraphNode<T> current = nodes.First.Value;
                        nodes.RemoveFirst();

                        foreach (GraphNode<T> neighbor in current.Neighbors)
                        {
                            if (neighbor.Value.Equals(meta))
                            {
                                return true;
                            }
                            else if (nodes.Contains(neighbor))
                            {
                                continue;
                            }
                            else
                            {
                                nodes.AddFirst(neighbor);
                                Console.WriteLine(nodes.Count);
                            }
                        }
                    }

                    return false;
                }
            }
            #endregion
        }
    }

    namespace Trees
    {
        class BinaryTreeNode<T>
        {
            #region FIELDS
            T value;
            BinaryTreeNode<T> left;
            BinaryTreeNode<T> right;
            #endregion

            #region CONSTRUCTORS
            public BinaryTreeNode(T value, BinaryTreeNode<T> left, BinaryTreeNode<T> right)
            {
                this.value = value;
                this.left = left;
                this.right = right;
            }
            #endregion

            #region PROPORTIES
            public T Value { get => value; set => this.value = value; }
            public BinaryTreeNode<T> Left { get => left; set => left = value; }
            public BinaryTreeNode<T> Right { get => right; set => right = value; }
            #endregion

            #region METHODS
            //Nothing required.
            #endregion
        }
        class BinaryTree<T> where T : IComparable
        {
            BinaryTreeNode<T> root;
            int count;

            public BinaryTree(T value)
            {
                root = new BinaryTreeNode<T>(value, null, null);
                count = 0;
            }

            public void Add(T value)
            {
                Add(root, value);
            }

            void Add(BinaryTreeNode<T> node, T value)
            {
                if (node == null)
                {
                    return;
                }
                else if (node.Value.CompareTo(value) > 0)
                {
                    if (node.Left != null)
                    {
                        Add(node.Left, value);
                    }
                    else
                    {
                        node.Left = new BinaryTreeNode<T>(value, null, null);
                    }
                }
                else if (node.Value.CompareTo(value) < 0)
                {
                    if (node.Right != null)
                    {
                        Add(node.Right, value);
                    }
                    else
                    {
                        node.Right = new BinaryTreeNode<T>(value, null, null);
                    }
                }
                else if (node.Value.CompareTo(value) == 0)
                {
                    node.Value = value;
                }
            }

            void Remove(BinaryTreeNode<T> node, T value)
            {
                if (node == null)
                {
                    return;
                }
                else if (node.Value.CompareTo(value) > 0)
                {
                    if (node.Left != null && node.Left.Value.Equals(value))
                    {
                        node.Left = node.Left.Left;
                    }
                }
            }
        }
        class HeapNode<T>
        {
            #region FIELDS
            T value;
            HeapNode<T> left;
            HeapNode<T> right;
            #endregion

            #region CONSTRUCTORS
            public HeapNode(T value, HeapNode<T> left, HeapNode<T> right)
            {
                this.value = value;
                this.left = left;
                this.right = right;
            }
            #endregion

            #region PROPORTIES
            public T Value { get => value; set => this.value = value; }
            public HeapNode<T> Left { get => left; set => left = value; }
            public HeapNode<T> Right { get => right; set => right = value; }
            #endregion

            #region METHODS
            //Nothing required.
            #endregion
        }
        class Heap<T> where T : IComparable
        {
            #region FIELDS
            HeapNode<T> root;
            int count;
            #endregion

            #region CONSTRUCTORS
            public Heap(T value)
            {
                root = new HeapNode<T>(value, null, null);
                count = 0;
            }
            #endregion

            #region PROPORTIES
            public HeapNode<T> Root { get => root; }
            public int Count { get => count; }
            #endregion

            #region METHODS
            public void Add(T value)
            {
                Add(root, value);
                count++;
            }

            void Add(HeapNode<T> node, T value)
            {
                if (node == null)
                {
                    return;
                }
                else if (node.Value.CompareTo(value) > 0)
                {
                    if (node.Left == null)
                    {
                        node.Left = new HeapNode<T>(value, null, null);
                    }
                    else if (node.Right == null)
                    {
                        node.Right = new HeapNode<T>(value, null, null);
                    }
                    else if (node.Left != null)
                    {
                        if (node.Left.Value.CompareTo(value) > 0)
                        {
                            Add(node.Left, value);
                        }
                        else if (node.Left.Value.CompareTo(value) < 0)
                        {
                            HeapNode<T> newVertex = new HeapNode<T>(value, null, null);
                            newVertex.Left = node.Left;
                            node.Left = newVertex;
                        }
                    }
                    else if (node.Right != null)
                    {
                        if (node.Right.Value.CompareTo(value) > 0)
                        {
                            Add(node.Right, value);
                        }
                        else if (node.Right.Value.CompareTo(value) < 0)
                        {
                            HeapNode<T> newVertex = new HeapNode<T>(value, null, null);
                            newVertex.Right = node.Right;
                            node.Right = newVertex;
                        }
                    }
                }
            }

            public void Print()
            {
                Print(root);
            }

            void Print(HeapNode<T> node)
            {
                if (node == null)
                {
                    return;
                }

                if (node.Left != null)
                {
                    Print(node.Left);
                }

                Console.Write($"{node.Value} ");

                if (node.Right != null)
                {
                    Print(node.Right);
                }
            }
            #endregion
        }
    }
}

namespace Testers
{
    class Tester
    {
        public static void Main(string[] args)
        {

        }
    }
}